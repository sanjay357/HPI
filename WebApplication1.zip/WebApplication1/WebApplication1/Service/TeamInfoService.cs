﻿using Couchbase;
using Couchbase.Core.Exceptions;
using System.Net.NetworkInformation;
using WebApplication1.Interface;
using WebApplication1.Model;

namespace WebApplication1.Service
{
    public class TeamInfoService :ITeamInfoInterface
    {

        private readonly ILogger<TeamInfoService> logger;
        public TeamInfoService(ILogger<TeamInfoService> logger)
        {
            
            this.logger = logger;
        }



        
        public async Task<ICluster> Initialize()
        {
            try
            {
               
                return await Retry();
            }

            catch (AuthenticationFailureException)
            {
                logger.LogError("Authentication error");
                throw;
            }

        }

        public async Task<ICluster> Retry()
        {
            var cluster = await Cluster.ConnectAsync("couchbase://localhost", "Gangadhar", "60801677@BSH");
            
            var bucket = await cluster.BucketAsync("TeamInfo");
            var collection = bucket.DefaultCollection();
            return cluster;
        }

        


    }
}
