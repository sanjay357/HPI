﻿namespace WebApplication1.Model
{
    public class Paging
    {
        public int start { get; set; }
        public int end { get; set; }
    }
}
