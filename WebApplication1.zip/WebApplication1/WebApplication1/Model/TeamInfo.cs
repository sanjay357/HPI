﻿namespace WebApplication1.Model
{
    public class TeamInfo
    {
            public string age { get; set; }
            public string id { get; set; }
            public string length { get; set; }
            public string name { get; set; }
            
        
    }
}
