﻿namespace WebApplication1.Model
{
    public class Orgtree
    {
        public string Clustername { get; set; }
        public string Shape { get; set; }
        public string Stream { get; set; }
        public string Team1 { get; set; }

        public string Team2 { get; set; }
        public string Team3 { get; set; }
        public string Team4 { get; set; }
        public string documentType { get; set; }
        public int id { get; set; }
        public string type { get; set; }
    }
}

