﻿namespace WebApplication1.Model
{
    public class TeamInformation
    {
        public string EmployeeID { get; set; }

        public string Firstname { get; set; }

        public string LastName { get; set; }

        public string Location { get; set; }

        public string MobileNo { get; set; }

        public string OrgUnit { get; set; }

        public string Roles { get; set; }
        

        public string documentType { get; set; }
        

        public string emailID { get; set; }
        public int id { get; set; }
        public string type { get; set; }
       
}
}
