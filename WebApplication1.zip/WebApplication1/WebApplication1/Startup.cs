﻿using Couchbase;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.Net.Http.Headers;
using System;
using System.Linq;
using System.Text;
using WebApplication1.Interface;
using WebApplication1.Service;

namespace WebApplication1
{
    public static  class Startup
    {
        public  static WebApplication initailizeAPP(string[] args)
        {
            var builder= WebApplication.CreateBuilder(args);
            Configureservices(builder);
            var app=builder.Build();
            Configure(app);
            return app;

        }

        public static void Configureservices(WebApplicationBuilder builder)
        {
            builder.Services.AddControllers();
            builder.Services.AddSwaggerGen(c => {
                c.ResolveConflictingActions(apiDescriptions => apiDescriptions.First());
                c.IgnoreObsoleteActions();
                c.IgnoreObsoleteProperties();
                c.CustomSchemaIds(type => type.FullName);
            });

            
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddScoped<ITeamInfoInterface , TeamInfoService>();
        }

        public static void Configure(WebApplication app)
        {


            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();

            app.MapControllers();

            app.Run();
        }


    }
}
