﻿using Couchbase;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics.Metrics;
using System.Net;
using System.Net.NetworkInformation;
using WebApplication1.Interface;
using WebApplication1.Model;
using WebApplication1.Service;
using System.Threading.Tasks;
using Couchbase.Core.Exceptions;
using Microsoft.Extensions.Logging;
using static Couchbase.Core.Diagnostics.Tracing.OuterRequestSpans.ManagerSpan;
using App.Metrics.Logging;
using Newtonsoft.Json.Linq;
using Couchbase.Query;

namespace WebApplication1.Controllers
{

    [ApiController]
    [Route("[controller]")]
    public class TeamInfoController: ControllerBase
    {
        private readonly ITeamInfoInterface _service;
        public TeamInfoController(ITeamInfoInterface service)
        {
            _service = service;
        }



        //[HttpGet("TeamInfo")]
        //public async Task<TeamInfo> Get()
        //{
        //    int id = 1;
        //    var cluster = await _service.Initialize();
        //    Paging pagings = new Paging();
        //    //var teaminfo = await _service.GetEmployeById(id);
        //    var queryResult = await cluster.QueryAsync<TeamInfo>("SELECT age,id,length,name FROM TeamInfo where id=" + id, new Couchbase.Query.QueryOptions());

        //    var bucket = await cluster.BucketAsync("TeamInfo");

        //    var collection = bucket.DefaultCollection();
        //    // TeamInfo variables = new TeamInfo();

        //    TeamInfo empList = new TeamInfo();

        //    await foreach (var row in queryResult)
        //    {
        //        empList = row;
        //    }
        //    TeamInfo emp = new TeamInfo();


        //    return empList;
        //}

        //[HttpGet("{id}")]
        //public async Task<TeamInformation> Get(int id)
        //{
            
        //    var cluster = await _service.Initialize();
        //    Paging pagings = new Paging();
        //    //var teaminfo = await _service.GetEmployeById(id);
        //    var queryResult = await cluster.QueryAsync<TeamInformation>("SELECT Day_On_Call,Distribution_Group,DocumentType,Id,Night_On_Call,Shape,Team,TeamMembers,Type FROM TeamInformation where Id=" + id, new Couchbase.Query.QueryOptions());

        //    var bucket = await cluster.BucketAsync("TeamInfo");

        //    var collection = bucket.DefaultCollection();
        //    // TeamInfo variables = new TeamInfo();

        //    TeamInformation empList = new TeamInformation();

        //    await foreach (var row in queryResult)
        //    {
        //        empList = row;
        //    }
        //    TeamInformation emp = new TeamInformation();


        //    return empList;
        //}

        [HttpGet("GetTeaminformation")]
        public async Task<TeamInformation> GetTeaminformation()
        {

            int id = 1;
            var cluster = await _service.Initialize();
            Paging pagings = new Paging();
            //var teaminfo = await _service.GetEmployeById(id);
            var queryResult = await cluster.QueryAsync<TeamInformation>("SELECT EmployeeID,Firstname,LastName,Location,MobileNo,OrgUnit,Roles,documentType,emailID,id,type FROM `master-data` where id=" + id, new Couchbase.Query.QueryOptions());

            var bucket = await cluster.BucketAsync("TeamInfo");
            
            
            var collection = bucket.DefaultCollection();
            // TeamInfo variables = new TeamInfo();

            TeamInformation empList = new TeamInformation();

            await foreach (var row in queryResult)
            {
                empList = row;
            }
            TeamInformation emp = new TeamInformation();


            return empList;
        }

        //[HttpPut("{id}")]
        //public async Task<IActionResult> Put(int id)
        //{
        //    if (id == 0)

        //    {
        //        throw new ArgumentNullException("id is empty");
        //    }

        //    TeamInfo value = new TeamInfo();
        //    value.id = "5";
        //    value.age = "6";
        //    value.name = "Testingsuccesfully";
        //    value.length ="100";
        //    var cluster = await _service.Initialize();
        //    var bucket = await cluster.BucketAsync("TeamInfo");
        //    var collection = bucket.DefaultCollection();
        //    var collectiondata = await collection.UpsertAsync(id.ToString(), value);

        //    if (collectiondata == null)
        //    {
               
        //    }
        //    return Ok();

        //}
        //[HttpPost]
        //public async Task<TeamInfo> PostTeamInfo(TeamInfo value)
        //{
        //    if (value.id == "0")
        //    {
        //        throw new ArgumentNullException("There is no id value");
        //    }
        //    var cluster = await _service.Initialize();

        //    var bucket = await cluster.BucketAsync("TeamInfo");
        //    var collection = bucket.DefaultCollection();
        //    string idvalue = value.id;
        //    var collectiondataa = await collection.InsertAsync(idvalue.ToString(), value);
        //    if (collectiondataa == null)
        //    {
        //        //logger.LogError("Error in creating");
        //    }

        //    return value;
        //}




        [HttpGet("master-data")]
        public async Task<Orgtree> GetMasterdata()
        {
            int id = 2;
            
            var cluster = await _service.Initialize();
            Paging pagings = new Paging();
            var queryResult1 = await cluster.QueryAsync<Orgtree>("SELECT Shape,Clustername,Stream,Team1,Team2,Team3,Team4,documentType,id,type FROM `master-data` where id=" + id, new Couchbase.Query.QueryOptions());
            //var teaminfo = await _service.GetEmployeById(id);
            var queryResult = await cluster.QueryAsync<Orgtree>("SELECT * FROM `master-data` where id=" + id);
            Orgtree orgtree = new Orgtree();
            Orgtree orgtree1 = new Orgtree();
            await foreach (var row in queryResult1)
            {
                orgtree1 = row;
            }
            await foreach (var row in queryResult)
            {
                orgtree = row;
            }
            return orgtree1;

           
        }
    }
}
