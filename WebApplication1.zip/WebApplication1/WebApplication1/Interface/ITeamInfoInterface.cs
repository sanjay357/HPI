﻿using Couchbase;
using WebApplication1.Model;

namespace WebApplication1.Interface
{
    public interface ITeamInfoInterface
    {

        Task<ICluster> Initialize();

       
        
       
    }
}
