using WebApplication1;

var app = Startup.initailizeAPP(args);
app.Run();

